import React from 'react';
import styles from './landingpage.module.css';
import { useNavigate } from 'react-router-dom';

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className = {StyleSheet.landingpage}>
      
      <h3>3....2.....1....anddddd</h3>
      <h1>Welcome to the Landing Page!</h1>
      <img src="Niknok.jpg" alt = "Landing Banner"/>
      <p>
        Hi guys! this is my very first website by using react! I am so glad that you guys can witness 
        my very first website! I am Dale Rayc'zar D. Yabut! Pleasure to meet you!I mostly do cosplays in my 
        free time. Please, feel free to view some of them!
      </p>

      <h2>Cosplays</h2>
      <img src="Iso.jpg" alt = "Landing Banner"/>
      <img src="Wriothesley.jpg" alt = "Landing Banner"/>
      <p>That's all I have for you on this page! Please click the "Go back" to go back in the log in.</p>
      <button onClick={() => navigate('/')}>Go Back</button>

      
    </div>
  );
}

export default LandingPage;